ALTER IGNORE TABLE accesos MODIFY id integer(10) unsigned NOT NULL auto_increment;
