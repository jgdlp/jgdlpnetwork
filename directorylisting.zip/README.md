Evoluted Directory Listing Script
==================================


System Requirements
--------------------
- PHP Version 5.3 or greater (5.6 recommended)
- GD Image Library
- ZipArchive PHP Extention (optional)

Installation
-------------
1. Unzip the provided files
2. Modify the configuration options as needed at the top of the index.php file.
3. Upload the index.php file to your web-accessible directory
4. You're done! Browse to the directory to see the script in action!

